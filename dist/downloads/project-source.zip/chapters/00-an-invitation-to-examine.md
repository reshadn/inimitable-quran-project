# An invitation to examine

*Opening essay · Draft 0.1 · 16 September 2026*

You need not begin this book by believing that the Qur’an is divine. Begin with a passage. Attend to what it says, how it says it, and what changes when its expression changes. Then ask how much that observation supports.

That is a modest beginning for a large claim. The Qur’an does not merely invite admiration. It presents itself as revelation and issues a challenge to those who doubt it. In 2:23 the challenge concerns producing a comparable surah. In 17:88 the claim extends to the combined efforts of humans and jinn. These passages establish the claim we are investigating. They do not, simply by being quoted, settle its truth. [Qur’an 2:23](https://quran.com/2/23), [17:88](https://quran.com/17/88)

The argument therefore asks more of us than noticing that a text is unusual. Every substantial work differs from other works in some respects. An unusual expression can be clumsy; a familiar one can be excellent. Nor does excellence by itself tell us that its author is more than human. Human literature offers extraordinary achievements, and a serious argument for revelation must make room for that fact.

Four propositions must remain separate: this text is distinctive; this text achieves something exceptional; the achievement is beyond human productive capacity, including exceptional genius; and revelation explains its origin. Each requires its own reasons. Neither the third nor the fourth can be borrowed from the first two without further argument. A comparative study may inform the case while remaining unable to establish universal human incapacity on its own.

We will begin with a sentence in a prayer. An old man speaks of weakness in his bones and a head overtaken by gray hair. The language turns grayness into a blaze. A reader may notice the image immediately. A more careful reading asks what happens when the head itself becomes the grammatical subject of that blazing, and how the image belongs to the prayer around it. The first sample chapter examines that question through a classical account of arrangement and meaning.

Then we will move to a complete composition. Al-ʿAṣr contains an oath, a judgment of loss, and an exception that includes both personal action and mutual counsel. Its brevity makes its structure inspectable. It also makes it tempting to confuse a striking interpretation with an exhaustive one. We will resist that temptation by considering the range of readings offered by commentators and by distinguishing grammatical observation from a claim about its effect.

Readers who know Arabic will be able to inspect some of these judgments directly. Readers who do not will need more explanation. A transparent translation can expose part of the reasoning, but it cannot reproduce every relation of sound, grammar, and convention. The aim is neither to hide behind expertise nor to pretend expertise is unnecessary. We should identify which judgments can be checked from an explanation and which require independent linguistic review.

The book will sometimes ask you to compare a passage with a deliberately plain reformulation. Such an exercise is a lens. It helps isolate a particular choice. It is not an adequate contest between the Qur’an and the best that human authors can produce. A weak paraphrase loses because it is weak. The comparative investigation must therefore bring in accomplished human compositions and allow them to display their own strengths.

It must also allow the Qur’an to be recognizable. Readers familiar with it cannot simply forget what they are reading because an experiment removes the title. Familiarity, devotion, and literary competence can coexist, but they are different influences. Our studies will record recognition and background rather than promise a blindness they cannot deliver.

Numbers can help when the question is precise. We can count a specified kind of repetition. We can examine how a defined alteration changes readers’ comprehension. We can compare judgments across passages, readers, and reciters. But a number answers the question built into its definition. A count of repeated words is not a measure of wisdom. A classifier that recognizes Qur’anic style has learned to distinguish samples; it has not discovered revelation.

The first computational appendix is intentionally elementary. It documents the source text, its numbered units, and the rules used to count written tokens. Its purpose is to make the analysis reproducible and reveal assumptions that attractive numerical claims often conceal. It supplies no score of literary excellence.

The larger argument will depend on the relationships among several kinds of evidence. Literary analysis must demonstrate actual achievements. Comparative research must ask whether the achievements remain exceptional under fair conditions. Historical work must independently examine the circumstances relevant to composition and transmission. Philosophical reasoning must then explain why revelation accounts for the resulting evidence better than the strongest available alternatives.

An exceptional human author is one of those alternatives. So are accounts involving inherited forms, a religious and linguistic environment, oral performance, and processes of composition or transmission. Their adequacy must be evaluated rather than dismissed by definition. Revelation, in turn, must not function as an empty label for whatever a current model fails to explain. The case for it requires substantive reasons.

This is an affirmative investigation. It aims to articulate the strongest responsible case for revelation. That purpose does not require protecting every familiar argument. If a numerical claim depends on changing the counting rule after seeing the answer, it should lose its place. If a historical premise is weaker than commonly reported, the book should say so. If a literary interpretation survives serious alternatives, it should receive the weight it earns.

The reader’s task is not to admire on command. It is to follow the evidence far enough to judge what has been shown, what remains contestable, and what further inference is justified. Our first task is simpler still: to read one expression carefully.
